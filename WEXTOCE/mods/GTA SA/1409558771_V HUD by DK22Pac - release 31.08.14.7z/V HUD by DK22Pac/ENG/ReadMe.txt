GTA V HUD by DK22Pac v0.815
Build on plugin SDK (31.08.2014)

==Installation==
Copy all files from folder "put to SA folder" into your GTA SA folder. Or if your ASI loader
supports loading from 'scripts' folder, you can put these files there.

==Distribution==
You can share this file (archive) on other resources (other than fee-sharing services).
You can't use this archive's content in your mods. Ask author (DK22Pac) for more
information.

Changing and publishing modification's setting and texture files is allowed.

==Thanks list==
Thanks to all people who waited for this mod and supported it in official forum topics:
http://gtaforums.com/topic/652697-sawip-gta5-hud-by-dk22pac
http://vol-gta.com/forum/46-2244-1
http://www.gforums.ru/topic/15614-gta5-hud-by-dk22pac
And in official DK22Pac's mods page:
http://www.vk.com/dk22pac
Thanks for testing to 13AG , Oksu, TJGM, Sandler, elMarco.
Thanks to AlexGT for helping with radio names list.
Thanks to BoPoH for his usual support.
Thanks to YaroslavSokol for some weapon icons.
Thanks to pluginSDK developers and GTA coders community - Deji, Wesser, Silent, Link, fastman.

==Plugin.dll compatibility==
This plugin was built with new version of Plugin SDK, which is not compatible with plugin.dll
(which was a part of older SDK version). This means, to launch this mod, you need to delete
plugin.dll and all plugins which use it.

==Other plugins compatibility==
It's not recommended to combine this plugin with others which replace game's HUD.

==Requirements==
GTA SA 1.0 US version
ASI Loader
Video card with Shader Model 2.0 support. Some shaders (blur shaders) need 3.0 shader model to be
loaded. If your video card doesn't support needed shader model, the loading of a shader will
be skipped.

==Contacts==
GTAForums (ENG) http://gtaforums.com/user/394532-dk22pac/
Vol-GTA (RUS) http://vol-gta.com/index/8-0-DK22Pac
libertycity (RUS) http://www.libertycity.ru/user/DK22Pac/
VK "DK Mods" page (RUS) http://www.vk.com/dk22pac